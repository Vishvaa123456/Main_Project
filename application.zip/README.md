# Objection_Detection

Link of the model weight
https://drive.google.com/file/d/1CNvWyL0a81TLVjcQY73pqFlB7dfZlMSG/view?usp=drive_link

Object detection weight link
https://drive.google.com/file/d/10nh0uMWH6KTmSZeCp1xOX63ihkNLvuSG/view?usp=drive_link
